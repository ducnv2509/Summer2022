package com.example.lab34;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab34ApplicationTests {

    @Test
    void contextLoads() {
    }

}
