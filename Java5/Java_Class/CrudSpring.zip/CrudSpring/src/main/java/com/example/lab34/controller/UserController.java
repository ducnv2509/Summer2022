package com.example.lab34.controller;

import com.example.lab34.entity.TypeGender;
import com.example.lab34.entity.TypeRole;
import com.example.lab34.entity.User;
import com.example.lab34.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping("/list")
    public String listAll(
            ModelMap modelMap,
            @RequestParam("p") Optional<Integer> p
    ) {

        return findPaginated(1, modelMap, "fullName", "asc");
    }

    @RequestMapping("/page/{pageNo}")
    public String findPaginated(@PathVariable("pageNo") int pageNo, ModelMap modelMap,
                                @RequestParam("sortField") String sortField,
                                @RequestParam("sortDir") String sorDir
    ) {
        List<TypeRole> listRole = new ArrayList<TypeRole>(EnumSet.allOf(TypeRole.class));
//        modelMap.addAttribute("listUser", this.userService.getUsers());
        modelMap.addAttribute("typeRole", listRole);
        modelMap.addAttribute("ACTION", "/users/save");
        modelMap.addAttribute("ACTION1", "/users/update");
        modelMap.addAttribute("DELETE", "/users/deleteAll");
        int pageSize = 5;
        Page<User> page = this.userService.findPaginated(pageNo, pageSize, sortField, sorDir);
        List<User> listUsers = page.getContent();
        modelMap.addAttribute("currentPage", pageNo);
        modelMap.addAttribute("totalPages", page.getTotalPages());
        modelMap.addAttribute("totalItems", page.getTotalElements());
        modelMap.addAttribute("sortField", sortField);
        modelMap.addAttribute("sortDir", sorDir);
        modelMap.addAttribute("reverseSortDir", sorDir.equals("asc") ? "desc" : "asc");
        modelMap.addAttribute("listUsers", listUsers);
        return "list_user";
    }


    @PostMapping("/save")
    public String save(@RequestParam("image") MultipartFile image,
                       @RequestParam("fullName") String fullName,
                       @RequestParam("username") String username,
                       @RequestParam("gender") TypeGender gender,
                       @RequestParam("email") String email,
                       @RequestParam("typeRole") TypeRole typeRole,
                       @RequestParam("password") String password,
                       @RequestParam("phone") String phone
    ) {
        this.userService.saveUserToDb(image, username, fullName, password, email, phone, typeRole, gender, new Date());
        System.out.println("OKKOKO");
        return "redirect:/users/list";
    }

    @PostMapping("/update")
    public String update(@RequestParam("image") MultipartFile image,
                         @RequestParam("fullName") String fullName,
                         @RequestParam("username") String username,
                         @RequestParam("gender") TypeGender gender,
                         @RequestParam("email") String email,
                         @RequestParam("typeRole") TypeRole typeRole,
                         @RequestParam("password") String password,
                         @RequestParam("phone") String phone,
                         @RequestParam("id") Long id
    ) {
        this.userService.updateUserToDb(image, id, username, fullName, password, email, phone, typeRole, gender);
        return "redirect:/users/list";
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        this.userService.deleteUser(id);
        return "redirect:/users/list";
    }


    @RequestMapping("/deleteAll")
    public String deleteAll(@RequestParam(value = "idAll", required = false) Long[] ids) {
        this.userService.deleteSomeUser(ids);
        return "redirect:/users/list";
    }

    @RequestMapping("/search")
    public String searchType(@RequestParam("keyword") Integer keyword, ModelMap modelMap) {
        Set<User> users = this.userService.searchUsers(keyword);
        System.out.println(this.userService.searchUsers(keyword));
        List<TypeRole> listRole = new ArrayList<TypeRole>(EnumSet.allOf(TypeRole.class));
        modelMap.addAttribute("listUsers", users);
        modelMap.addAttribute("typeRole", listRole);
        modelMap.addAttribute("ACTION", "/users/save");
        modelMap.addAttribute("ACTION1", "/users/update");
        return "list_user";
    }


}
