package com.example.lab34.service.Impl;

import com.example.lab34.entity.TypeGender;
import com.example.lab34.entity.TypeRole;
import com.example.lab34.entity.User;
import com.example.lab34.repository.IUserRepository;
import com.example.lab34.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private IUserRepository userRepository;

    @Override
    public void saveUserToDb(MultipartFile file, String username, String fullName, String password, String email, String phone, TypeRole typeRole, TypeGender typeGender, Date createDate) {
        User user = new User();
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (fileName.contains("..")) {
            System.out.println("not a a valid file");
        }
        try {
            user.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        user.setDateCreate(new Date());
        user.setEmail(email);
        user.setUsername(username);
        user.setFullName(fullName);
        user.setPhone(phone);
        user.setPassword(password);
        user.setTypeGender(typeGender);
        user.setTypeRole(typeRole);
        userRepository.save(user);
    }

    @Override
    public void updateUserToDb(MultipartFile file, Long id, String username, String fullName, String password, String email, String phone, TypeRole typeRole, TypeGender typeGender) {
        User user = new User();
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (fileName.contains("..")) {
            System.out.println("not a a valid file");
        }
        try {
            user.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        user.setId(id);
        user.setEmail(email);
        user.setUsername(username);
        user.setFullName(fullName);
        user.setPhone(phone);
        user.setPassword(password);
        user.setTypeGender(typeGender);
        user.setTypeRole(typeRole);
        userRepository.save(user);
    }

    @Transactional
    @Override
    public void deleteSomeUser(Long[] ids) {
        this.userRepository.deleteUsersWithIds(Arrays.asList(ids));
    }

    @Override
    public Page<User> getPages(Pageable s) {
        return this.userRepository.findAll(s);
    }

    @Override
    public Page<User> findPaginated(int pageNo, int pageSize,  String sortField, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name())?Sort.by(sortField).ascending() : Sort.by(sortField).descending();
        Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
        return this.userRepository.findAll(pageable);
    }


    @Override
    public User addUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User updateUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public Set<User> getUsers() {
        return new LinkedHashSet<>(this.userRepository.findAll());
    }

    @Override
    public Set<User> searchUsers(Integer type) {
        return new LinkedHashSet<>(this.userRepository.findAllByTypeRole(type));
    }

    @Override
    public User getUser(Long userId) {
        return this.userRepository.findById(userId).get();
    }

    @Override
    public void deleteUser(Long userId) {
        User user = new User();
        user.setId(userId);
        this.userRepository.delete(user);
    }


}
