package com.example.lab34.DTO;

import com.example.lab34.entity.TypeGender;
import com.example.lab34.entity.TypeRole;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.*;

@Data
public class UserDTO {
//    @GeneratedValue(strategy=GenerationType.IDENTITY)
//    private Long id;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String phone;
    private MultipartFile image;
    private Integer typeRole;
    private Integer typeGender;
}
