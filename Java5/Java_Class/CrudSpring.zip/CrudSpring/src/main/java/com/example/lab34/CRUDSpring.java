package com.example.lab34;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CRUDSpring {

    public static void main(String[] args) {
        SpringApplication.run(CRUDSpring.class, args);
    }

}
