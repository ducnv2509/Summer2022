package com.example.lab34.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "`users`")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String phone;
    private String image;
    private Date dateCreate;
    @Enumerated(EnumType.ORDINAL)
    private TypeRole typeRole;
    @Enumerated(EnumType.ORDINAL)
    private TypeGender typeGender;

    public User(String fullName, String email, String password, String image, String phone, String username, Integer typeGender, Integer typeRole, Date dateCreate) {
    }
    public User(Long id, String fullName, String email, String password, String image, String phone, String username, Integer typeGender, Integer typeRole,  Date dateCreate) {
    }
}
