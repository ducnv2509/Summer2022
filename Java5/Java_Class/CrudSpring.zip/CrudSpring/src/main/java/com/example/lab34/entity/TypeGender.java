package com.example.lab34.entity;

public enum TypeGender {
    MALE, FEMALE
}
